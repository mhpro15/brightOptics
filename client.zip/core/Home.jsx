import React from 'react';


import './css/mystyle.css'


export default function Home(){ 
// const classes = useStyles()
return (
    

  <div className= "container1">
     <img src="./images/slider-bg.jpg" alt="glasses" ></img>
     <div className="top-left">  Bright Optics!</div>
     <div className = "button" > <a href="/shop"><button className = "button1" type="button">Buy Now</button></a></div>

  </div>

 
)}



